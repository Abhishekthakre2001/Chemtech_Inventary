<?php
$host = "localhost";
$username = "chemtech_chemtech_inventory";
$password = "1pIR-5rK[1I}=oYf";
$database = "chemtech_chemtech_inventory"; // change this to your DB name

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
