<?php

// CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

session_start();
include '../connection/connection.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

try {
    // Prepare SQL statement to fetch all suppliers
    $sql = "SELECT 
        id,
        supplier_name as supplierName,
        contact_person as contactPerson,
        contact_number as contactNumber,
        email,
        address,
        products_provided as provideproduct,
        bank_name as bankName,
        bank_branch as bankBranch,
        bank_city as bankCity,
        account_number as bankAccount,
        ifsc_code as ifscCode,
        created_at as createdAt,
        updated_at as updatedAt
        FROM suppliers 
        ORDER BY id DESC";

    $result = $conn->query($sql);
    
    if (!$result) {
        throw new Exception('Database error: ' . $conn->error);
    }

    $suppliers = [];
    while ($row = $result->fetch_assoc()) {
        $suppliers[] = $row;
    }

    echo json_encode([
        'success' => true,
        'data' => $suppliers
    ]);

    $conn->close();

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
