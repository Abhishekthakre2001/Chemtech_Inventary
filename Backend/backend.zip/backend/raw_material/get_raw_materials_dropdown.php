<?php
session_start();
include '../connection/connection.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

try {
    // Query to fetch id, raw_material_name, quantity, and quantity_unit for dropdown
    $sql = "SELECT id, raw_material_name as name, quantity, quantity_unit 
            FROM raw_materials 
            WHERE quantity > 0
            ORDER BY raw_material_name ASC";

    $result = $conn->query($sql);
    
    if (!$result) {
        throw new Exception('Database error: ' . $conn->error);
    }
    
    $materials = [];
    while ($row = $result->fetch_assoc()) {
        $materials[] = [
            'id' => (int)$row['id'],
            'name' => $row['name'],
            'quantity' => (float)$row['quantity'],
            'quantity_unit' => $row['quantity_unit']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'data' => $materials
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

$conn->close();
?>
