<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Include database connection
require_once '../connection/connection.php';

try {
    // Get batch recreation ID from query parameter
    $batch_recreation_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    
    if (empty($batch_recreation_id)) {
        throw new Exception('Batch recreation ID is required');
    }
    
    // Fetch batch recreation details
    $stmt = $conn->prepare(
        "SELECT br.id, br.original_batch_id, br.recreated_batch_name, br.recreated_batch_date, 
                br.recreated_batch_size, br.recreated_batch_unit, br.created_at, br.updated_at,
                b.batch_name as original_batch_name, b.batch_date as original_batch_date,
                b.batch_size as original_batch_size, b.batch_unit as original_batch_unit
         FROM batch_recreation br
         JOIN batch b ON br.original_batch_id = b.id
         WHERE br.id = ?"
    );
    $stmt->bind_param('i', $batch_recreation_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception('Batch recreation not found');
    }
    
    $batch_recreation = $result->fetch_assoc();
    
    // Fetch raw materials for this batch recreation
    $stmt = $conn->prepare(
        "SELECT rm.id, rm.raw_material_name as name, brrm.quantity_used as quantity, 
                brrm.unit_used as unit, brrm.percentage as percentage
         FROM batch_recreation_raw_material_map brrm
         JOIN raw_materials rm ON brrm.raw_material_id = rm.id
         WHERE brrm.batch_recreation_id = ?"
    );
    $stmt->bind_param('i', $batch_recreation_id);
    $stmt->execute();
    $materials_result = $stmt->get_result();
    
    $materials = [];
    while ($row = $materials_result->fetch_assoc()) {
        $materials[] = $row;
    }
    
    $batch_recreation['materials'] = $materials;
    
    // Return success response
    echo json_encode([
        'success' => true,
        'data' => $batch_recreation
    ]);
    
} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching batch recreation: ' . $e->getMessage()
    ]);
    
} finally {
    // Close statement and connection
    if (isset($stmt)) {
        $stmt->close();
    }
    $conn->close();
}
