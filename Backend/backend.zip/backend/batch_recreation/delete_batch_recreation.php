<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Include database connection
require_once '../connection/connection.php';

try {
    // Get batch recreation ID from query parameter
    $batch_recreation_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    
    if (empty($batch_recreation_id)) {
        throw new Exception('Batch recreation ID is required');
    }
    
    // Start transaction
    $conn->begin_transaction();
    
    // Delete raw materials mapping first (foreign key constraint)
    $stmt = $conn->prepare("DELETE FROM batch_recreation_raw_material_map WHERE batch_recreation_id = ?");
    $stmt->bind_param("i", $batch_recreation_id);
    
    if (!$stmt->execute()) {
        throw new Exception("Error deleting batch recreation materials: " . $stmt->error);
    }
    
    // Delete batch recreation record
    $stmt = $conn->prepare("DELETE FROM batch_recreation WHERE id = ?");
    $stmt->bind_param("i", $batch_recreation_id);
    
    if (!$stmt->execute()) {
        throw new Exception("Error deleting batch recreation: " . $stmt->error);
    }
    
    // Check if any rows were affected
    if ($stmt->affected_rows === 0) {
        throw new Exception("Batch recreation not found");
    }
    
    // Commit transaction
    $conn->commit();
    
    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Batch recreation deleted successfully'
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    if (isset($conn)) {
        $conn->rollback();
    }
    
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'success' => false,
        'message' => 'Error deleting batch recreation: ' . $e->getMessage()
    ]);
    
} finally {
    // Close statement and connection
    if (isset($stmt)) {
        $stmt->close();
    }
    if (isset($conn)) {
        $conn->close();
    }
}
