<?php
// Enable output buffering to prevent any accidental output
ob_start();

// Set headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Include database connection
require_once '../connection/connection.php';

// Function to log errors
function logError($message, $data = null) {
    $logMessage = '[' . date('Y-m-d H:i:s') . '] ' . $message . "\n";
    if ($data) {
        $logMessage .= 'Data: ' . print_r($data, true) . "\n";
    }
    error_log($logMessage, 3, __DIR__ . '/batch_recreation_errors.log');
}

// Function to send JSON response and exit
function sendJsonResponse($success, $message, $data = null, $statusCode = 200) {
    // Clear any previous output
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    
    http_response_code($statusCode);
    header('Content-Type: application/json');
    
    $response = [
        'success' => $success,
        'message' => $message
    ];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    echo json_encode($response);
    exit;
}

try {
    // Get POST data
    $jsonData = file_get_contents('php://input');
    $data = json_decode($jsonData, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON data: ' . json_last_error_msg());
    }
    
    // Log received data for debugging
    logError('Received data:', $data);
    
    // Validate required fields
    $requiredFields = [
        'original_batch_id', 
        'recreated_batch_name', 
        'recreated_batch_date', 
        'recreated_batch_size', 
        'recreated_batch_unit', 
        'materials'
    ];
    
    $missingFields = [];
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || (is_string($data[$field]) && trim($data[$field]) === '')) {
            $missingFields[] = $field;
        }
    }
    
    if (!empty($missingFields)) {
        throw new Exception('Missing required fields: ' . implode(', ', $missingFields));
    }
    
    $original_batch_id = (int)$data['original_batch_id'];
    $recreated_batch_name = trim($data['recreated_batch_name']);
    $recreated_batch_date = $data['recreated_batch_date'];
    $recreated_batch_size = (float)$data['recreated_batch_size'];
    $recreated_batch_unit = trim($data['recreated_batch_unit']);
    $materials = $data['materials'];
    
    // Additional validation
    if ($original_batch_id <= 0) {
        throw new Exception('Invalid original batch ID');
    }
    
    if ($recreated_batch_size <= 0) {
        throw new Exception('Batch size must be greater than 0');
    }
    
    if (!is_array($materials) || empty($materials)) {
        throw new Exception('No materials provided');
    }
    
    // Start transaction
    if (!$conn->begin_transaction()) {
        throw new Exception('Failed to start transaction: ' . $conn->error);
    }
    
    try {
        // Insert batch recreation record
        $stmt = $conn->prepare(
            "INSERT INTO batch_recreation 
             (original_batch_id, recreated_batch_name, recreated_batch_date, recreated_batch_size, recreated_batch_unit) 
             VALUES (?, ?, ?, ?, ?)"
        );
        
        if (!$stmt) {
            throw new Exception('Failed to prepare batch recreation statement: ' . $conn->error);
        }
        
        $stmt->bind_param(
            "issds", 
            $original_batch_id, 
            $recreated_batch_name, 
            $recreated_batch_date, 
            $recreated_batch_size, 
            $recreated_batch_unit
        );
        
        if (!$stmt->execute()) {
            throw new Exception("Error creating batch recreation: " . $stmt->error);
        }
        
        $batch_recreation_id = $conn->insert_id;
        $stmt->close();
        
        // Insert raw materials
        $materialStmt = $conn->prepare(
            "INSERT INTO batch_recreation_raw_material_map 
             (batch_recreation_id, raw_material_id, quantity_used, unit_used, percentage) 
             VALUES (?, ?, ?, ?, ?)"
        );
        
        if (!$materialStmt) {
            throw new Exception('Failed to prepare material statement: ' . $conn->error);
        }
        
        foreach ($materials as $index => $material) {
            // Validate material data
            if (empty($material['raw_material_id'])) {
                throw new Exception('Invalid material data at index ' . $index . ': Missing raw_material_id');
            }
            
            $raw_material_id = (int)$material['raw_material_id'];
            $quantity_used = (float)($material['quantity_used'] ?? 0);
            $unit_used = $material['unit_used'] ?? 'kg';
            $percentage = (float)($material['percentage'] ?? 0);
            
            if ($raw_material_id <= 0) {
                throw new Exception('Invalid raw material ID at index ' . $index);
            }
            
            if ($quantity_used <= 0) {
                throw new Exception('Quantity must be greater than 0 for material at index ' . $index);
            }
            
            $materialStmt->bind_param(
                "iidds", 
                $batch_recreation_id, 
                $raw_material_id, 
                $quantity_used, 
                $unit_used, 
                $percentage
            );
            
            if (!$materialStmt->execute()) {
                throw new Exception("Error adding material to batch recreation: " . $materialStmt->error);
            }
        }
        
        $materialStmt->close();
        
        // Commit transaction
        if (!$conn->commit()) {
            throw new Exception('Failed to commit transaction: ' . $conn->error);
        }
        
        // Return success response
        sendJsonResponse(
            true,
            'Batch recreation created successfully',
            [
                'id' => $batch_recreation_id,
                'batch_name' => $recreated_batch_name,
                'materials_count' => count($materials)
            ]
        );
        
    } catch (Exception $e) {
        // Rollback transaction on error
        if (isset($conn)) {
            $conn->rollback();
        }
        throw $e; // Re-throw to be caught by outer catch
    }
    
} catch (Exception $e) {
    // Log the error
    logError('Error in add_batch_recreation: ' . $e->getMessage(), $data ?? null);
    
    // Return error response
    sendJsonResponse(
        false,
        'Error: ' . $e->getMessage(),
        null,
        $e->getCode() >= 400 && $e->getCode() < 600 ? $e->getCode() : 500
    );
}
