<?php
// Always send CORS headers for all request methods
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// Respond to preflight OPTIONS requests immediately with 200 status
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../connection/connection.php';


// Parse JSON input (if sending id in body)
$data = json_decode(file_get_contents('php://input'), true);
$id = isset($data['id']) ? intval($data['id']) : (isset($_GET['id']) ? intval($_GET['id']) : 0);

if (!$id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Batch ID is required']);
    exit();
}

try {
    $conn->begin_transaction();

    // If no ON DELETE CASCADE, delete materials manually:
    // $stmtMaterials = $conn->prepare("DELETE FROM standard_batch_materials WHERE batch_id = ?");
    // $stmtMaterials->bind_param("i", $id);
    // $stmtMaterials->execute();
    // $stmtMaterials->close();

    // Delete batch
    $stmtBatch = $conn->prepare("DELETE FROM standard_batch WHERE id = ?");
    $stmtBatch->bind_param("i", $id);
    $stmtBatch->execute();

    if ($stmtBatch->affected_rows === 0) {
        throw new Exception("Batch with ID $id not found");
    }

    $conn->commit();

    echo json_encode(['success' => true, 'message' => 'Batch deleted successfully']);
} catch (Exception $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    if (isset($stmtBatch)) $stmtBatch->close();
    $conn->close();
}
