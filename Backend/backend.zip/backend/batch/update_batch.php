<?php
session_start();
require_once '../connection/connection.php';
header('Content-Type: application/json');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Get POST data
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true);
    
    // Log request details for debugging
    error_log('=== Batch Update Request ===');
    error_log('Request Method: ' . $_SERVER['REQUEST_METHOD']);
    error_log('Content Type: ' . ($_SERVER['CONTENT_TYPE'] ?? 'Not set'));
    error_log('Raw input: ' . $rawInput);
    error_log('Parsed data: ' . print_r($data, true));
    
    // Check for JSON parse errors
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON data: ' . json_last_error_msg());
    }
    
    // Validate required fields
    $requiredFields = ['id', 'batch_name', 'batch_date', 'batch_size', 'batch_unit'];
    $missingFields = [];
    
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || (is_string($data[$field]) && trim($data[$field]) === '')) {
            $missingFields[] = $field;
        }
    }
    
    if (!empty($missingFields)) {
        throw new Exception('Missing required fields: ' . implode(', ', $missingFields));
    }
    
    // Sanitize input
    $batch_id = (int)$data['id'];
    $batch_name = $conn->real_escape_string(trim($data['batch_name']));
    $batch_date = $conn->real_escape_string(trim($data['batch_date']));
    $batch_size = (float)$data['batch_size'];
    $batch_unit = $conn->real_escape_string(trim($data['batch_unit']));
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // First, get the current batch raw materials to calculate stock adjustments
        $currentMaterials = [];
        $result = $conn->query("SELECT raw_material_id, quantity_used 
                              FROM batch_raw_material_map 
                              WHERE batch_id = $batch_id");
        
        while ($row = $result->fetch_assoc()) {
            $currentMaterials[$row['raw_material_id']] = $row['quantity_used'];
        }
        
        // Update batch
        $stmt = $conn->prepare("UPDATE batch 
                              SET batch_name = ?, batch_date = ?, batch_size = ?, batch_unit = ?, 
                                  updated_at = NOW() 
                              WHERE id = ?");
        $stmt->bind_param("ssdsi", $batch_name, $batch_date, $batch_size, $batch_unit, $batch_id);
        
        if (!$stmt->execute()) {
            throw new Exception("Error updating batch: " . $stmt->error);
        }
        
        // If no rows were affected, the batch didn't exist
        if ($stmt->affected_rows === 0) {
            throw new Exception('Batch not found');
        }
        
        // Delete existing raw materials for this batch
        $conn->query("DELETE FROM batch_raw_material_map WHERE batch_id = $batch_id");
        
        // Validate raw materials
        if (!isset($data['raw_materials']) || !is_array($data['raw_materials'])) {
            error_log('No raw materials array found in request');
            $data['raw_materials'] = [];
        }
        
        // Validate percentage sum is 100%
        if (!empty($data['raw_materials'])) {
            $totalPercentage = 0;
            foreach ($data['raw_materials'] as $rm) {
                if (isset($rm['percentage'])) {
                    $totalPercentage += (float)$rm['percentage'];
                }
            }
            
            if (abs($totalPercentage - 100.0) > 0.01) {
                throw new Exception("Total percentage must equal 100%. Current total: {$totalPercentage}%");
            }
        }
        
        error_log('Raw materials data: ' . print_r($data['raw_materials'], true));
        
        // If raw materials are provided, validate and process them
        if (!empty($data['raw_materials'])) {
            error_log('Processing ' . count($data['raw_materials']) . ' raw materials');
            $stmt = $conn->prepare("INSERT INTO batch_raw_material_map 
                                  (batch_id, raw_material_id, quantity_used, percentage, unit_used, notes) 
                                  VALUES (?, ?, ?, ?, ?, ?)");
            
            foreach ($data['raw_materials'] as $rm) {
                error_log('Processing raw material: ' . print_r($rm, true));
                
                // Validate raw material data
                if (empty($rm['raw_material_id']) || !isset($rm['quantity_used']) || !isset($rm['unit_used']) || $rm['unit_used'] === '') {
                    $errorMsg = 'Invalid raw material data: ' . print_r($rm, true);
                    error_log($errorMsg);
                    throw new Exception($errorMsg);
                }
                
                $rm_id = (int)$rm['raw_material_id'];
                $quantity = (float)$rm['quantity_used'];
                $unit = $conn->real_escape_string(trim($rm['unit_used']));
                
                // Check if raw material exists and get its unit
                $checkStmt = $conn->prepare("SELECT id, quantity, quantity_unit FROM raw_materials WHERE id = ?");
                $checkStmt->bind_param("i", $rm_id);
                $checkStmt->execute();
                $material = $checkStmt->get_result()->fetch_assoc();
                $checkStmt->close();
                
                if (!$material) {
                    throw new Exception("Raw material with ID $rm_id not found");
                }
                
                // Use the raw material's unit from the database
                $unit = $material['quantity_unit'];
                
                // Calculate stock adjustment
                $adjustment = $quantity;
                if (isset($currentMaterials[$rm_id])) {
                    $adjustment -= $currentMaterials[$rm_id];
                }
                
                // Check if enough stock is available for the adjustment
                if (isset($material['quantity']) && $material['quantity'] + $adjustment < 0) {
                    throw new Exception("Insufficient stock for raw material ID $rm_id");
                }
                
                // Add to batch_raw_material_map (with notes column)
                $percentage = isset($rm['percentage']) ? (float)$rm['percentage'] : 0;
                $notes = isset($rm['notes']) ? $conn->real_escape_string(trim($rm['notes'])) : '';
                $stmt->bind_param("iiddss", $batch_id, $rm_id, $quantity, $percentage, $unit, $notes);
                if (!$stmt->execute()) {
                    throw new Exception("Error adding raw material to batch: " . $stmt->error);
                }
                
                // Update raw material stock (adjust based on the difference)
                if ($adjustment != 0) {
                    $updateStmt = $conn->prepare("UPDATE raw_materials SET quantity = quantity - ? WHERE id = ?");
                    $updateStmt->bind_param("di", $adjustment, $rm_id);
                    if (!$updateStmt->execute()) {
                        throw new Exception("Error updating raw material stock: " . $updateStmt->error);
                    }
                    $updateStmt->close();
                }
            }
            $stmt->close();
        }
        
        // Commit transaction
        $conn->commit();
        
        echo json_encode([
            'success' => true, 
            'message' => 'Batch updated successfully',
            'batch_id' => $batch_id
        ]);
        
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        throw $e;
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$conn->close();
?>
