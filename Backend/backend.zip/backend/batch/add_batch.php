<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    // Handle preflight request
    http_response_code(200);
    exit();
}

include '../connection/connection.php';  // adjust path to your DB connection

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!$data) {
        throw new Exception("Invalid JSON input");
    }

    // Validate main batch fields
    $requiredBatchFields = ['batchName', 'batchDate', 'batchSize', 'batchUnit', 'materials'];
    foreach ($requiredBatchFields as $field) {
        if (empty($data[$field])) {
            throw new Exception("Missing required field: $field");
        }
    }

    if (!is_array($data['materials']) || count($data['materials']) === 0) {
        throw new Exception("Materials must be a non-empty array");
    }

    // Start transaction
    $conn->begin_transaction();

    // Insert batch record
    $stmtBatch = $conn->prepare("INSERT INTO standard_batch (batchDate, batchName, batchSize, batchUnit) VALUES (?, ?, ?, ?)");
    if (!$stmtBatch) {
        throw new Exception("Prepare failed: " . $conn->error);
    }

    $stmtBatch->bind_param(
        "ssds",
        $data['batchDate'],
        $data['batchName'],
        $data['batchSize'],
        $data['batchUnit']
    );

    if (!$stmtBatch->execute()) {
        throw new Exception("Batch insert failed: " . $stmtBatch->error);
    }

    $batchId = $stmtBatch->insert_id;
    $stmtBatch->close();

    // Prepare statement for materials insert
    $stmtMaterial = $conn->prepare("INSERT INTO standard_batch_materials (batch_id, name, notes, percentage, quantity, unit) VALUES (?, ?, ?, ?, ?, ?)");
    if (!$stmtMaterial) {
        throw new Exception("Prepare failed: " . $conn->error);
    }

    // Insert each material
    foreach ($data['materials'] as $material) {
        // Validate material fields
        $requiredMaterialFields = ['rawMaterial', 'quantity', 'percentage', 'unit'];
        foreach ($requiredMaterialFields as $mfield) {
            if (!isset($material[$mfield]) || $material[$mfield] === '') {
                throw new Exception("Missing material field: $mfield");
            }
        }

        $name = $material['rawMaterial'];
        $notes = $material['notes'] ?? '';  // optional
        $percentage = floatval($material['percentage']);
        $quantity = floatval($material['quantity']);
        $unit = $material['unit'];

        $stmtMaterial->bind_param("issdds", $batchId, $name, $notes, $percentage, $quantity, $unit);

        if (!$stmtMaterial->execute()) {
            throw new Exception("Material insert failed: " . $stmtMaterial->error);
        }
    }

    $stmtMaterial->close();

    // Commit transaction
    $conn->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Batch and materials saved successfully',
        'batchId' => $batchId
    ]);

} catch (Exception $e) {
    if ($conn->errno) {
        $conn->rollback();
    }
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

$conn->close();
?>
