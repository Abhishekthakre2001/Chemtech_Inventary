-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2025 at 05:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chemtech_inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

CREATE TABLE `batch` (
  `id` int(11) NOT NULL,
  `batch_name` varchar(100) NOT NULL,
  `batch_date` date NOT NULL,
  `batch_size` decimal(10,2) NOT NULL,
  `batch_unit` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch`
--

INSERT INTO `batch` (`id`, `batch_name`, `batch_date`, `batch_size`, `batch_unit`, `created_at`, `updated_at`) VALUES
(3, 'teat', '2025-07-24', 0.04, 'L', '2025-07-24 22:41:04', '2025-07-24 22:41:04'),
(4, 'new', '2025-07-26', 10.00, 'L', '2025-07-26 21:08:39', '2025-07-26 21:08:39'),
(5, 'test batch', '2025-07-26', 12.00, 'L', '2025-07-26 21:25:34', '2025-07-26 21:25:34'),
(6, 'kb', '2025-07-26', 110.00, 'L', '2025-07-26 21:33:33', '2025-07-26 21:33:33'),
(7, 'kln', '2025-07-26', 11.00, 'L', '2025-07-26 21:41:47', '2025-07-26 21:41:47'),
(8, 'kjvr', '2025-07-26', 121.00, 'L', '2025-07-26 21:51:48', '2025-07-26 21:51:48'),
(9, 'fhfh', '2025-07-26', 14.00, 'L', '2025-07-26 22:00:19', '2025-07-26 22:00:19'),
(10, 'jbf', '2025-07-26', 16.00, 'L', '2025-07-26 22:49:59', '2025-07-26 22:49:59'),
(11, 'jbkd', '2025-07-26', 101.00, 'L', '2025-07-26 22:52:18', '2025-07-26 22:52:18'),
(12, 'jbkd', '2025-07-26', 101.00, 'L', '2025-07-26 22:52:31', '2025-07-26 22:52:31'),
(13, 'jvb', '2025-07-26', 19.00, 'L', '2025-07-26 22:58:47', '2025-07-26 22:58:47'),
(21, 'jhv', '2025-07-26', 12.00, 'L', '2025-07-26 23:09:52', '2025-07-26 23:09:52'),
(25, 'iuhj1hjb', '2025-07-27', 1.00, 'L', '2025-07-27 13:45:10', '2025-07-27 19:22:10'),
(26, 'iuhj1', '2025-07-27', 1.00, 'L', '2025-07-27 13:45:24', '2025-07-27 13:45:24'),
(29, 'jvh', '2025-07-27', 3.00, 'L', '2025-07-27 17:29:04', '2025-07-27 17:29:04'),
(30, 'jvh', '2025-07-27', 3.00, 'L', '2025-07-27 17:29:29', '2025-07-27 17:29:29');

-- --------------------------------------------------------

--
-- Table structure for table `batch_raw_material_map`
--

CREATE TABLE `batch_raw_material_map` (
  `id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `raw_material_id` int(11) NOT NULL,
  `quantity_used` decimal(10,2) NOT NULL,
  `percentage` decimal(5,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `unit_used` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_raw_material_map`
--

INSERT INTO `batch_raw_material_map` (`id`, `batch_id`, `raw_material_id`, `quantity_used`, `notes`, `unit_used`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 10.00, NULL, 'Kg', '2025-07-24 22:41:04', '2025-07-24 22:41:04'),
(2, 10, 1, 16.00, NULL, 'Kg', '2025-07-26 22:49:59', '2025-07-26 22:49:59'),
(3, 11, 1, 20.00, NULL, 'Kg', '2025-07-26 22:52:18', '2025-07-26 22:52:18'),
(4, 12, 1, 20.00, NULL, 'Kg', '2025-07-26 22:52:31', '2025-07-26 22:52:31'),
(5, 13, 1, 19.00, NULL, 'Kg', '2025-07-26 22:58:47', '2025-07-26 22:58:47'),
(6, 21, 1, 12.00, NULL, 'Kg', '2025-07-26 23:09:52', '2025-07-26 23:09:52'),
(8, 26, 1, 1.00, '', 'Kg', '2025-07-27 13:45:24', '2025-07-27 13:45:24'),
(9, 26, 1, 1.00, 'jkbj', 'Kg', '2025-07-27 13:45:24', '2025-07-27 13:45:24'),
(10, 29, 2, 3.00, '', '0', '2025-07-27 17:29:04', '2025-07-27 17:29:04'),
(11, 30, 2, 3.00, '', '0', '2025-07-27 17:29:29', '2025-07-27 17:29:29'),
(12, 30, 2, 3.00, '', '0', '2025-07-27 17:29:29', '2025-07-27 17:29:29'),
(14, 25, 1, 1.00, '', 'Kg', '2025-07-27 19:22:10', '2025-07-27 19:22:10');

-- --------------------------------------------------------

--
-- Table structure for table `batch_recreation`
--

CREATE TABLE `batch_recreation` (
  `id` int(11) NOT NULL,
  `original_batch_id` int(11) NOT NULL,
  `recreated_batch_name` varchar(100) NOT NULL,
  `recreated_batch_date` date NOT NULL,
  `recreated_batch_size` decimal(10,2) NOT NULL,
  `recreated_batch_unit` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_recreation`
--

INSERT INTO `batch_recreation` (`id`, `original_batch_id`, `recreated_batch_name`, `recreated_batch_date`, `recreated_batch_size`, `recreated_batch_unit`, `created_at`, `updated_at`) VALUES
(1, 3, 'Test Recreation', '2025-07-27', 5.00, 'L', '2025-07-27 21:23:48', '2025-07-27 21:23:48');

-- --------------------------------------------------------

--
-- Table structure for table `batch_recreation_raw_material_map`
--

CREATE TABLE `batch_recreation_raw_material_map` (
  `id` int(11) NOT NULL,
  `batch_recreation_id` int(11) NOT NULL,
  `raw_material_id` int(11) NOT NULL,
  `quantity_used` decimal(10,2) NOT NULL,
  `unit_used` varchar(50) NOT NULL,
  `percentage` decimal(5,2) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `batch_recreation_raw_material_map`
--

INSERT INTO `batch_recreation_raw_material_map` (`id`, `batch_recreation_id`, `raw_material_id`, `quantity_used`, `unit_used`, `percentage`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 2.50, 'Kg', 50.00, '2025-07-27 21:23:48', '2025-07-27 21:23:48');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `created_at`, `updated_at`) VALUES
(2, 'kjxdn', '2025-07-22 21:28:23', '2025-07-22 21:28:23'),
(3, 'kjb', '2025-07-22 22:47:38', '2025-07-22 22:47:38');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `email`, `password`) VALUES
(1, 'rohit@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `raw_materials`
--

CREATE TABLE `raw_materials` (
  `id` int(11) NOT NULL,
  `purchase_code` varchar(100) NOT NULL,
  `raw_material_name` varchar(100) NOT NULL,
  `raw_material_code` varchar(100) NOT NULL,
  `rate_landed` decimal(10,2) NOT NULL,
  `date_in` date NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `quantity_unit` varchar(50) NOT NULL,
  `purchase_price` decimal(10,2) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `raw_materials`
--

INSERT INTO `raw_materials` (`id`, `purchase_code`, `raw_material_name`, `raw_material_code`, `rate_landed`, `date_in`, `expiry_date`, `category_id`, `quantity`, `quantity_unit`, `purchase_price`, `supplier_id`, `created_at`, `updated_at`) VALUES
(1, 'Sunt in unde sint v', 'Hamilton Maldonado', 'Commodi sunt amet i', 75.00, '1971-02-17', '2017-12-30', 2, 3.00, 'Kg', 477.00, 5, '2025-07-19 21:29:16', '2025-07-27 13:45:24'),
(2, 'test', 'trst', '5641', 663.00, '2025-07-22', '2025-07-30', 2, 36.00, 'Kg', 100.00, 12, '2025-07-22 21:11:17', '2025-07-27 19:37:01');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `supplier_name` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text NOT NULL,
  `products_provided` text DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `bank_branch` varchar(100) DEFAULT NULL,
  `bank_city` varchar(50) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `supplier_name`, `contact_person`, `contact_number`, `email`, `address`, `products_provided`, `bank_name`, `bank_branch`, `bank_city`, `account_number`, `ifsc_code`, `created_at`, `updated_at`) VALUES
(2, 'new', 'new', '123456789', 'yuhjv@gmail.com', 'ug', 'oihio', '', '', '', '', '', '2025-07-19 15:58:04', '2025-07-19 15:58:04'),
(3, 'new', 'new', '123456789', 'yuhjv@gmail.com', 'ug', 'oihio', '', '', '', '', '', '2025-07-19 15:58:04', '2025-07-19 15:58:04'),
(4, 'new123', 'hvhj', '1234567890', 'kjbkrje@gmail.com', 'kbjkce', 'ibkjcr', '', '', '', '', '', '2025-07-19 16:00:49', '2025-07-19 16:00:49'),
(5, 'new123', 'hvhj', '1234567890', 'kjbkrje@gmail.com', 'kbjkce', 'ibkjcr', '', '', '', '', '', '2025-07-19 16:00:49', '2025-07-19 16:00:49'),
(12, 'hgc', '3515', '4846845310', 'yfhjv@jhv.com', 'jhv', 'jyuv', '-', '-', '-', '', '', '2025-07-19 17:17:33', '2025-07-19 17:17:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `batch`
--
ALTER TABLE `batch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `batch_raw_material_map`
--
ALTER TABLE `batch_raw_material_map`
  ADD PRIMARY KEY (`id`),
  ADD KEY `batch_id` (`batch_id`),
  ADD KEY `raw_material_id` (`raw_material_id`);

--
-- Indexes for table `batch_recreation`
--
ALTER TABLE `batch_recreation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `original_batch_id` (`original_batch_id`);

--
-- Indexes for table `batch_recreation_raw_material_map`
--
ALTER TABLE `batch_recreation_raw_material_map`
  ADD PRIMARY KEY (`id`),
  ADD KEY `batch_recreation_id` (`batch_recreation_id`),
  ADD KEY `raw_material_id` (`raw_material_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`) USING HASH;

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `raw_materials`
--
ALTER TABLE `raw_materials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_category_rm` (`category_id`),
  ADD KEY `fk_supplier_rm` (`supplier_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_supplier_name` (`supplier_name`),
  ADD KEY `idx_contact_number` (`contact_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `batch`
--
ALTER TABLE `batch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `batch_raw_material_map`
--
ALTER TABLE `batch_raw_material_map`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `batch_recreation`
--
ALTER TABLE `batch_recreation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `batch_recreation_raw_material_map`
--
ALTER TABLE `batch_recreation_raw_material_map`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `raw_materials`
--
ALTER TABLE `raw_materials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `batch_raw_material_map`
--
ALTER TABLE `batch_raw_material_map`
  ADD CONSTRAINT `batch_raw_material_map_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `batch` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `batch_raw_material_map_ibfk_2` FOREIGN KEY (`raw_material_id`) REFERENCES `raw_materials` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `batch_recreation`
--
ALTER TABLE `batch_recreation`
  ADD CONSTRAINT `batch_recreation_ibfk_1` FOREIGN KEY (`original_batch_id`) REFERENCES `batch` (`id`);

--
-- Constraints for table `batch_recreation_raw_material_map`
--
ALTER TABLE `batch_recreation_raw_material_map`
  ADD CONSTRAINT `batch_recreation_raw_material_map_ibfk_1` FOREIGN KEY (`batch_recreation_id`) REFERENCES `batch_recreation` (`id`),
  ADD CONSTRAINT `batch_recreation_raw_material_map_ibfk_2` FOREIGN KEY (`raw_material_id`) REFERENCES `raw_materials` (`id`);

--
-- Constraints for table `raw_materials`
--
ALTER TABLE `raw_materials`
  ADD CONSTRAINT `fk_category_rm` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_supplier_rm` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
