<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../connection/connection.php';

try {
    $input = json_decode(file_get_contents("php://input"), true);

    if (!$input || !isset($input['id'])) {
        throw new Exception("Batch ID is required");
    }

    $batchId = intval($input['id']);
    $batchDate = $input['batchDate'];
    $batchName = $input['batchName'];
    $batchSize = $input['batchSize'];
    $batchUnit = $input['batchUnit'];
    $materials = $input['materials'];

    // ✅ Update main batch table
    $stmt = $conn->prepare("UPDATE standard_batch SET batchDate=?, batchName=?, batchSize=?, batchUnit=? WHERE id=?");
    $stmt->bind_param("ssisi", $batchDate, $batchName, $batchSize, $batchUnit, $batchId);
    $stmt->execute();
    $stmt->close();

    // ✅ Fetch existing materials for this batch
    $existingMaterials = [];
    $res = $conn->query("SELECT * FROM standard_batch_materials WHERE batch_id = $batchId");
    while ($row = $res->fetch_assoc()) {
        $existingMaterials[$row['id']] = $row;
    }

    // ✅ Check stock for each new material BEFORE updating anything
    foreach ($materials as $mat) {
        $name = $mat['name'];
        $qty = floatval($mat['quantity']);

        // Fetch current stock
        $stockRes = $conn->prepare("SELECT quantity FROM raw_materials WHERE raw_material_name = ?");
        $stockRes->bind_param("s", $name);
        $stockRes->execute();
        $stockRes->bind_result($currentStock);
        $stockRes->fetch();
        $stockRes->close();

        if ($currentStock === null) {
            throw new Exception("Raw material '$name' not found in inventory");
        }

        if ($currentStock <= 0 || $qty > $currentStock) {
            throw new Exception("Insufficient stock for raw material '$name'");
        }
    }

    // ✅ Delete removed materials (not present in payload)
    $receivedIds = array_map(fn($m) => intval($m['id']), $materials);
    foreach ($existingMaterials as $dbId => $dbMat) {
        if (!in_array($dbId, $receivedIds)) {
            // Return stock before deleting
            $returnQty = floatval($dbMat['quantity']);
            $returnName = $dbMat['name'];

            $rmStmt = $conn->prepare("UPDATE raw_materials SET quantity = quantity + ? WHERE raw_material_name = ?");
            $rmStmt->bind_param("ds", $returnQty, $returnName);
            $rmStmt->execute();
            $rmStmt->close();

            // Delete material
            $delStmt = $conn->prepare("DELETE FROM standard_batch_materials WHERE id=?");
            $delStmt->bind_param("i", $dbId);
            $delStmt->execute();
            $delStmt->close();
        }
    }

    // ✅ Process payload (update or insert)
    foreach ($materials as $mat) {
        $matId = intval($mat['id']);
        $name = $mat['name'];
        $qty = floatval($mat['quantity']);
        $percentage = floatval($mat['percentage']);
        $unit = $mat['unit'];

        if (isset($existingMaterials[$matId])) {
            // Already exists → update
            $dbQty = floatval($existingMaterials[$matId]['quantity']);
            $diff = $qty - $dbQty; // positive = consume more, negative = return stock

            $rmStmt = $conn->prepare("UPDATE raw_materials SET quantity = quantity - ? WHERE raw_material_name = ?");
            $rmStmt->bind_param("ds", $diff, $name);
            $rmStmt->execute();
            $rmStmt->close();

            $upStmt = $conn->prepare("UPDATE standard_batch_materials SET name=?, quantity=?, percentage=?, unit=? WHERE id=?");
            $upStmt->bind_param("sdssi", $name, $qty, $percentage, $unit, $matId);
            $upStmt->execute();
            $upStmt->close();

        } else {
            // New material → insert
            $insStmt = $conn->prepare("INSERT INTO standard_batch_materials (batch_id, name, quantity, percentage, unit) VALUES (?, ?, ?, ?, ?)");
            $insStmt->bind_param("isdss", $batchId, $name, $qty, $percentage, $unit);
            $insStmt->execute();
            $insStmt->close();

            // Deduct stock
            $rmStmt = $conn->prepare("UPDATE raw_materials SET quantity = quantity - ? WHERE raw_material_name = ?");
            $rmStmt->bind_param("ds", $qty, $name);
            $rmStmt->execute();
            $rmStmt->close();
        }
    }

    echo json_encode([
        "success" => true,
        "message" => "Batch updated successfully"
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
} finally {
    $conn->close();
}
?>
