<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle CORS preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Include database connection
require_once '../connection/connection.php';

try {
    // Fetch all batch recreations with count of raw materials
    $stmt = $conn->prepare(
        "SELECT br.id, br.original_batch_id, br.recreated_batch_name, br.recreated_batch_date, 
                br.recreated_batch_size, br.recreated_batch_unit, br.created_at, br.updated_at,
                b.batch_name as original_batch_name,
                COUNT(brrm.id) as raw_material_count
         FROM batch_recreation br
         JOIN batch b ON br.original_batch_id = b.id
         LEFT JOIN batch_recreation_raw_material_map brrm ON br.id = brrm.batch_recreation_id
         GROUP BY br.id, br.original_batch_id, br.recreated_batch_name, br.recreated_batch_date, 
                  br.recreated_batch_size, br.recreated_batch_unit, br.created_at, br.updated_at, b.batch_name
         ORDER BY br.created_at DESC"
    );
    $stmt->execute();
    $result = $stmt->get_result();
    
    $batch_recreations = [];
    while ($row = $result->fetch_assoc()) {
        $batch_recreations[] = $row;
    }
    
    // Return success response
    echo json_encode([
        'success' => true,
        'data' => $batch_recreations
    ]);
    
} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching batch recreations: ' . $e->getMessage()
    ]);
    
} finally {
    // Close statement and connection
    if (isset($stmt)) {
        $stmt->close();
    }
    $conn->close();
}
